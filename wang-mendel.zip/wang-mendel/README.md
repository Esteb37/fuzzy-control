# wang-mendel
A Wang-Mendel based implementation for predicting the Mackey-Glass time series using a FLS
The implementation is based on the original code found here: [ADONIS](https://ieeexplore.ieee.org/document/8790770/algorithms#algorithms)
